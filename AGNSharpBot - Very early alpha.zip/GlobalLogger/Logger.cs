﻿using System;

namespace GlobalLogger
{
    /// <summary>
    /// My logger class.
    ///     (nearly) every console output goes through here first to output file name, line number, time date etc to the console for better debugging
    /// </summary>
    public class Logger
    {

        public static Logger Instance = _instance ?? (_instance = new Logger());
        private static Logger _instance;

        public Logger()
        {
            //TODO: Setup file logging to %APPDATA% or simalar
        }

        public void WriteConsole(string msg, [System.Runtime.CompilerServices.CallerMemberName]
            string memberName = "", [System.Runtime.CompilerServices.CallerFilePath]
            string memberFilePath = "", [System.Runtime.CompilerServices.CallerLineNumber]
            int memberLineNumber = 0)
        {
            Console.WriteLine($"{DateTime.Now:g} [{memberName}|{System.IO.Path.GetFileName(memberFilePath)}|{memberLineNumber}] - {msg}");
        }
    }
}
