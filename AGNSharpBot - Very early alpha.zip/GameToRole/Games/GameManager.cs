﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Discord;
using Discord.Rest;
using Discord.WebSocket;
using Newtonsoft.Json;

namespace GameToRole.Games
{
    class GameManager
    {
        // Some clever code that creates a single instance of the GameManager class, and it can be used anywhere in the code from itself.
        //      Saves having to create an instance inside Program() and use that constantly.
        //      It also means you can use the same instance over any loaded plugin, anywhere.
        public static GameManager Instance = _instance ?? (_instance = new GameManager());
        private static GameManager _instance;

        // Holds the game entries - loaded from JSON at some point.
        private readonly List<GameEntry> gameEntries = new List<GameEntry>();

        // Is just a useful var for the Discord client socket
        private DiscordSocketClient _discordSocket;

        private const string GameManagerConfigFilePath = "Plugins\\Config\\GameToRole.json";

        public GameManager()
        {
            // Load our config
            if (System.IO.File.Exists(GameManagerConfigFilePath))
            {
                GlobalLogger.Logger.Instance.WriteConsole("Game2Role -> Loading Configuration File");
                var config =
                    JsonConvert.DeserializeObject<List<GameEntry>>(
                        System.IO.File.ReadAllText(GameManagerConfigFilePath));

                // Load out game entries from the config to our class
                foreach (var x in config)
                    gameEntries.Add(x);

                GlobalLogger.Logger.Instance.WriteConsole($"Game2Role -> Loaded {gameEntries.Count} game entries");
            }
            else
                GlobalLogger.Logger.Instance.WriteConsole("Game2Role -> Unable to find configuration file, starting as new.");
        }

        public Task StartGameManager(DiscordSocketClient discordSocket)
        {
            _discordSocket = discordSocket;
            _discordSocket.GuildMemberUpdated += DiscordSocketOnGuildMemberUpdatedAsync;

            GlobalLogger.Logger.Instance.WriteConsole("StartGameManager Loaded - Now listening for user update events");

            return Task.CompletedTask;
        }

        public async Task ScanAllUsers(SocketMessage sktMessage)
        {
            foreach (var x in _discordSocket.Guilds.First(x => x.IsConnected).Users)
            {
                if ( x.Activity == null ) continue;

                await sktMessage.Channel.SendMessageAsync($"Scanning User {x.Username}");
                await DiscordSocketOnGuildMemberUpdatedAsync(x, x);
            }
        }

        private async Task DiscordSocketOnGuildMemberUpdatedAsync(SocketGuildUser socketGuildUser, SocketGuildUser guildUser)
        {
            GlobalLogger.Logger.Instance.WriteConsole($"{socketGuildUser.Username} triggered DiscordSocketOnGuildMemberUpdatedAsync");

            RestRole createdRestRole = null;

            try
            {
                if (guildUser.Activity != null && guildUser.Activity.Type == ActivityType.Playing)
                {
                    var playingActivity = (Game) guildUser.Activity;
                    if (playingActivity.Name.Equals("")) return;

                    // First check if the game already exists, if so add the user to the role
                    var gameFinder = gameEntries.Where(x => string.Equals(x.Name, playingActivity.Name, StringComparison.CurrentCultureIgnoreCase))
                        .DefaultIfEmpty(null).FirstOrDefault();

                    // First check if the user is already part of that role, if they are there is no need to keep going.
                    if (guildUser.Roles.Where(x => gameFinder != null && x.Id == gameFinder.DiscordRoleId).DefaultIfEmpty(null)
                            .FirstOrDefault() != null)
                        return;

                    // This section detects if the game they are playing is an already existing role, which it cannot be at this point, as the game itself doesnt exist yet.
                    // aka, someones trying to be an arse.

                    // if it's the first one, check the roles, otherwise check the game entries
                    SocketRole gameRoleDetector;
                    if (gameEntries == null)
                        gameRoleDetector = socketGuildUser.Guild.Roles
                            .Where(x => x.Name.Equals(playingActivity.Name, StringComparison.CurrentCultureIgnoreCase))
                            .DefaultIfEmpty(null).FirstOrDefault();
                    else
                        gameRoleDetector = socketGuildUser.Guild.Roles
                            .Where(x => gameFinder != null && x.Name.Equals(gameFinder.Name, StringComparison.CurrentCultureIgnoreCase))
                            .DefaultIfEmpty(null).FirstOrDefault();

                    if (gameRoleDetector != null)
                    {
                        GlobalLogger.Logger.Instance.WriteConsole(
                            $"WARNING: {socketGuildUser.Username} attempted to auto-join a role called {playingActivity.Name} which is not meant for them");
                        return;
                    }

                    if (gameFinder == null)
                    {
                        // The game is new, set it up
                        // Create the role
                        try
                        {
                            GlobalLogger.Logger.Instance.WriteConsole(
                                $"GAME2ROLE - Found a new game, Creating role for it [{playingActivity.Name}]");

                            var permissions = new GuildPermissions();
                            createdRestRole = await socketGuildUser.Guild.CreateRoleAsync(playingActivity.Name, permissions);

                            await createdRestRole.ModifyAsync(properties => properties.Mentionable = true );

                            GlobalLogger.Logger.Instance.WriteConsole(
                                $"GAME2ROLE -    -> Role Created [{createdRestRole.Id}]");

                            gameEntries.Add(new GameEntry(playingActivity.Name, createdRestRole.Id));

                            await socketGuildUser.AddRoleAsync(createdRestRole);

                            SaveGameEntries();
                        }
                        catch (Exception ex)
                        {
                            // Something went wrong
                            GlobalLogger.Logger.Instance.WriteConsole($"ERROR\r\n{ex.Message}\r\n\r\nSTACK:\r\n{ex.StackTrace}");

                            // Cleanup the role
                            if (createdRestRole != null)
                                await createdRestRole.DeleteAsync();
                        }

                    }
                    else
                    {
                        // The game is already known, get the role ID and add to it
                        GlobalLogger.Logger.Instance.WriteConsole($"{socketGuildUser.Username} is playing {playingActivity.Name} - Game exists in DB");
                        var gameRole = socketGuildUser.Guild.Roles.Where(x => x.Id == gameFinder.DiscordRoleId)
                            .DefaultIfEmpty(null).FirstOrDefault();

                        if (gameRole == null) return;

                        GlobalLogger.Logger.Instance.WriteConsole($"  -> Adding user to role with ID {gameRole.Id}");
                        await socketGuildUser.AddRoleAsync(gameRole);
                    }

                    GlobalLogger.Logger.Instance.WriteConsole(
                        $"{guildUser.Username} is playing {playingActivity.Name}");
                }
                else if (guildUser.Activity != null && guildUser.Activity.Type == ActivityType.Listening)
                {
                    var listeningActivity = (SpotifyGame) guildUser.Activity;
                    GlobalLogger.Logger.Instance.WriteConsole(
                        $"{guildUser.Username} is listening to {listeningActivity.Artists.First()} - {listeningActivity.TrackTitle}");
                }
            }
            catch (Exception ex)
            {
                // ignored
                //todo: dont ignore this
            }
        }

        private void SaveGameEntries()
        {
            if (!System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(GameManagerConfigFilePath)))
                System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(GameManagerConfigFilePath));

            System.IO.File.WriteAllText(GameManagerConfigFilePath, JsonConvert.SerializeObject(gameEntries, Formatting.Indented));
        }
    }
}
