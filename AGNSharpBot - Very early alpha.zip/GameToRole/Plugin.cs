﻿using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Threading.Tasks;
using Discord.WebSocket;
using PluginInterface;

namespace GameToRole
{
    [Export(typeof(IPlugin))]
    public class Plugin : IPlugin
    {
        string IPlugin.Name => "Game 2 Roles";
        List<string> IPlugin.Commands => new List<string>() { "ScanGamers" };
        List<PluginRequestTypes.PluginRequestType> IPlugin.RequestTypes =>
            new List<PluginRequestTypes.PluginRequestType> { PluginRequestTypes.PluginRequestType.COMMAND };

        public DiscordSocketClient DiscordClient { get; set; }

        void IPlugin.ExecutePlugin()
        {
            GlobalLogger.Logger.Instance.WriteConsole($"GameToRole.dll v0.3.1 Plugin Loading...");
            Games.GameManager.Instance.StartGameManager(DiscordClient);
        }

        async Task IPlugin.Command(string command, string message, SocketMessage sktMessage)
        {

            if (((SocketGuildUser) sktMessage.Author).Roles.Any(x => x.Permissions.Administrator))
            {
                await sktMessage.Channel.SendMessageAsync("Attempting to scan all users for games...");
                await Games.GameManager.Instance.ScanAllUsers(sktMessage);
            }
            else
            {
                await sktMessage.Channel.SendMessageAsync(
                    $"Sorry {sktMessage.Author.Username}, You do not have permission to run that command");
            }
        }

        Task IPlugin.Message(string message, SocketMessage sktMessage)
        {
            return Task.CompletedTask;
        }
    }
}