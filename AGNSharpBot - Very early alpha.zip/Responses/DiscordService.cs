﻿using System.Threading.Tasks;
using Discord.Commands;

namespace Responses
{
    class DiscordService : ModuleBase<SocketCommandContext>
    {
        [Command("plugintest")]
        public Task PingAsync()
            => ReplyAsync("I'm a plugin!");
    }
}
