﻿using PluginInterface;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Threading.Tasks;
using Discord.WebSocket;

namespace AGNSharpBot.PluginHandler
{
    internal class PluginManager
    {
        [ImportMany] // This is a signal to the MEF framework to load all matching exported assemblies.
        private IEnumerable<IPlugin> Plugins { get; set; }

        public static PluginManager Instance = _instance ?? (_instance = new PluginManager());
        private static PluginManager _instance;

        public void LoadPlugins()
        {
            GlobalLogger.Logger.Instance.WriteConsole("Loading Plugins from Plugins directory");

            var catalog = new DirectoryCatalog("Plugins");
            using (var container = new CompositionContainer(catalog))
            {
                try
                {
                    container.ComposeParts(this);
                }
                catch (System.Reflection.ReflectionTypeLoadException ex)
                {
                    GlobalLogger.Logger.Instance.WriteConsole("Unable to load plugins...");

                    foreach (var x in ex.LoaderExceptions)
                        GlobalLogger.Logger.Instance.WriteConsole(x.Message);
                }
                catch (Exception ex)
                {
                    GlobalLogger.Logger.Instance.WriteConsole(ex.Message);
                }
            }

            PreExecute();

            DiscordHandler.Client.Instance.GetDiscordSocket().Ready += () =>
            {
                GlobalLogger.Logger.Instance.WriteConsole("Discord Is Ready - Executing Plugins");
                foreach (var plugin in Plugins)
                    plugin.ExecutePlugin();

                return Task.CompletedTask;
            };

            GlobalLogger.Logger.Instance.WriteConsole("Plugins loaded");
        }
        
        public async Task DispatchMessage(SocketMessage sktMessage)
        {
            // Fire each of our plugins message method
            foreach (var plugin in Plugins)
            {
                if ( plugin.RequestTypes.Contains(PluginRequestTypes.PluginRequestType.MESSAGE) )
                    await plugin.Message(sktMessage.Content, sktMessage);

                if (plugin.RequestTypes.Contains(PluginRequestTypes.PluginRequestType.COMMAND))
                {
                    if (sktMessage.Content.First() != Configuration.Discord.Instance.CommandPrefix) continue;

                    var cmdWord = sktMessage.Content.Split(' ').First()
                        .TrimStart(Configuration.Discord.Instance.CommandPrefix);
                    if (plugin.Commands.Any(x => x.Equals(cmdWord, StringComparison.CurrentCultureIgnoreCase)))
                        await plugin.Command(cmdWord, sktMessage.Content, sktMessage);
                }
            }
        }
        

        public IEnumerable<IPlugin> GetPlugins()
        {
            return Plugins;
        }

        private void PreExecute()
        {
            if (Plugins == null) return;

            foreach (var plugin in Plugins)
            {
                GlobalLogger.Logger.Instance.WriteConsole($"Plugin '{plugin.Name}' Detected - Init Plugin");
                plugin.DiscordClient = DiscordHandler.Client.Instance.GetDiscordSocket();
            }
        }
    }
}
