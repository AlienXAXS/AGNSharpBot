﻿using System;
using System.Threading.Tasks;
using Discord;
using Discord.WebSocket;
using Microsoft.Extensions.DependencyInjection;

namespace AGNSharpBot.DiscordHandler
{
    class Client
    {
        public static Client Instance = _instance ?? (_instance = new Client());
        private static Client _instance;

        private DiscordSocketClient DiscordSocket;
        private IServiceProvider _services;

        public async Task InitDiscordClient(IServiceProvider services)
        {
            _services = services;

            DiscordSocket = services.GetRequiredService<DiscordSocketClient>();

            DiscordSocket.Log += message =>
            {
                GlobalLogger.Logger.Instance.WriteConsole(message.Message);
                return Task.CompletedTask;
            };

            DiscordSocket.MessageReceived += message => PluginHandler.PluginManager.Instance.DispatchMessage(message);
            await _services.GetRequiredService<Services.CommandHandlingService>().InitializeAsync();
        }

        public DiscordSocketClient GetDiscordSocket()
        {
            return DiscordSocket;
        }

        internal async Task ConnectToDiscordAsync()
        {
            await DiscordSocket.LoginAsync(TokenType.Bot, Configuration.Discord.Instance.Token);
            await DiscordSocket.StartAsync();
        }
    }
}
