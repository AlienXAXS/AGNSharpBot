﻿using System;
using System.Threading.Tasks;
using AGNSharpBot.DiscordHandler;
using AGNSharpBot.PluginHandler;
using Discord;


namespace AGNSharpBot
{
    class Program
    {
        static void Main(string[] args) => new Program().MainAsync().GetAwaiter().GetResult();
        private readonly Client _discordClient = Client.Instance;

        public async Task MainAsync()
        {
            GlobalLogger.Logger.Instance.WriteConsole("AGN Discord Bot Loading...");

            try
            {
                Configuration.Discord.Instance.LoadConfiguration();
            }
            catch (Configuration.Discord.Exceptions.MissingConfigurationFile)
            {
                GlobalLogger.Logger.Instance.WriteConsole(
                    "\r\n\r\nYou must provide a config.json file, rename the config.json.example to config.json before loading this application");
                Console.WriteLine("Press <ENTER> to exit");
                Console.ReadKey();
                return;
            }
            catch (Configuration.Discord.Exceptions.InvalidConfigurationFile)
            {
                GlobalLogger.Logger.Instance.WriteConsole(
                    "\r\n\r\nThe provided config.json is invalid, unable to load.");
                Console.WriteLine("Press <ENTER> to exit");
                Console.ReadKey();
                return;
            }
            // Get our discord service definitions
            var serviceHandler = new ServiceDefiner();

            // Start our discord client
            GlobalLogger.Logger.Instance.WriteConsole("Loading Discord");
            await _discordClient.InitDiscordClient(serviceHandler.GetServiceProvider());

            // Load plugins
            PluginManager.Instance.LoadPlugins();

            GlobalLogger.Logger.Instance.WriteConsole("Connecting to Discord");
            await _discordClient.ConnectToDiscordAsync();

            _discordClient.GetDiscordSocket().Ready += () =>
            {
                GlobalLogger.Logger.Instance.WriteConsole("DISCORD CLIENT READY!");
                return Task.CompletedTask;
            };

            await GetUserInputAsync();
        }

        private async Task GetUserInputAsync()
        {
            while (true)
            {
                var txt = Console.ReadLine();
                switch (txt.ToLower())
                {
                    case "quit":
                    case "exit":
                        if (_discordClient.GetDiscordSocket().ConnectionState == ConnectionState.Connected)
                        {
                            await _discordClient.GetDiscordSocket().LogoutAsync();
                            _discordClient.GetDiscordSocket().Dispose();
                        }

                        return;

                    default:
                        Console.WriteLine("Unknown command, type 'exit' or 'quit' to stop the bot");
                        break;
                }
            }
        }
    }
}
