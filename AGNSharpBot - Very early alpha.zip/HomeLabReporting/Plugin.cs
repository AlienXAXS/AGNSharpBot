﻿using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Threading.Tasks;
using Discord.WebSocket;
using PluginInterface;

namespace HomeLabReporting
{
    [Export(typeof(IPlugin))]
    public class Plugin : IPlugin
    {
        string IPlugin.Name => "AlienX's HomeLab Reporting";
        public DiscordSocketClient DiscordClient { get; set; }
        List<string> IPlugin.Commands => new List<string>();
        List<PluginRequestTypes.PluginRequestType> IPlugin.RequestTypes =>
            new List<PluginRequestTypes.PluginRequestType> { PluginRequestTypes.PluginRequestType.COMMAND };

        public void ExecutePlugin()
        {
            GlobalLogger.Logger.Instance.WriteConsole($"HomeLabReporting.dll Plugin Loading...");
        }

        public Task Command(string command, string message, SocketMessage sktMessage)
        {
            return Task.CompletedTask;
        }

        public Task Message(string message, SocketMessage sktMessage)
        {
            return Task.CompletedTask;
        }
    }
}
